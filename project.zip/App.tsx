import React, { useState, useEffect, useMemo } from 'react';
import { AppTab, DealershipTask, Employee, FinanceRecord, ReceivableRecord, DocumentRecord, UserRole, TaskStatus } from './types';
import { DataService } from './services/dataService';
import Dashboard from './components/Dashboard';
import TeamManager from './components/TeamManager';
import FinanceManager from './components/FinanceManager';
import ReceivablesManager from './components/ReceivablesManager';
import DocumentManager from './components/DocumentManager';
import LoginScreen from './components/LoginScreen';
import { 
  ClipboardList, 
  Users,
  Car,
  Wallet,
  ArrowDownCircle,
  FileText,
  LogOut,
  Loader2,
  AlertTriangle,
  Bell,
  X
} from 'lucide-react';

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<Employee | null>(() => {
    const saved = localStorage.getItem('dealership_current_user');
    return saved ? JSON.parse(saved) : null;
  });

  const [activeTab, setActiveTab] = useState<AppTab>(AppTab.TASKS);
  const [isSyncing, setIsSyncing] = useState(false);
  const [appReady, setAppReady] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [notification, setNotification] = useState<{title: string, message: string} | null>(null);
  
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [tasks, setTasks] = useState<DealershipTask[]>([]);
  const [financeRecords, setFinanceRecords] = useState<FinanceRecord[]>([]);
  const [receivableRecords, setReceivableRecords] = useState<ReceivableRecord[]>([]);
  const [documents, setDocuments] = useState<DocumentRecord[]>([]);

  // Request browser notification permission
  useEffect(() => {
    if ("Notification" in window && Notification.permission === "default") {
      Notification.requestPermission();
    }
  }, []);

  // Secure Data Loading Logic
  useEffect(() => {
    let unsubscribeTasks: (() => void) | undefined;

    const loadData = async () => {
      try {
        setIsSyncing(true);
        
        // 1. Load Employees (Fetch Once)
        let e = await DataService.getEmployees();

        // --- SEEDING DEFAULT ADMIN USER ---
        // Ensure the specific requested mobile number exists as a manager
        const targetMobile = "8668678238";
        if (!e.find(emp => emp.mobile === targetMobile)) {
          const adminUser: Employee = {
            id: 'admin_seed_8668678238',
            name: 'Admin',
            mobile: targetMobile,
            role: 'manager'
          };
          // Persist to DB
          await DataService.addEmployee(adminUser);
          // Add to local list immediately
          e.push(adminUser);
        }
        // -----------------------------

        setEmployees(e);

        // 2. Subscribe to Tasks (Real-time)
        unsubscribeTasks = DataService.getTasks((updatedTasks) => {
          setTasks(updatedTasks);
        });

        // 3. Conditionally load sensitive data ONLY if manager (Fetch Once)
        if (currentUser?.role === 'manager') {
          const [f, r, d] = await Promise.all([
            DataService.getFinance(),
            DataService.getReceivables(),
            DataService.getDocuments()
          ]);
          setFinanceRecords(f);
          setReceivableRecords(r);
          setDocuments(d);
        } else {
          // Security: Clear sensitive state if not manager
          setFinanceRecords([]);
          setReceivableRecords([]);
          setDocuments([]);
        }

        setAppReady(true);
      } catch (err) {
        console.error("Failed to load dealership data:", err);
        setLoadError("Critical error loading data. Please refresh.");
      } finally {
        setIsSyncing(false);
      }
    };

    loadData();

    return () => {
      if (unsubscribeTasks) unsubscribeTasks();
    };
  }, [currentUser]); // Re-run whenever user changes to ensure permissions are enforced

  // Notification Check
  useEffect(() => {
    if (currentUser && tasks.length > 0) {
      const lastSeen = parseInt(localStorage.getItem(`last_seen_${currentUser.id}`) || "0");
      const newTasks = tasks.filter(t => t.assignedTo === currentUser.id && t.createdAt > lastSeen && t.status === 'pending');
      
      if (newTasks.length > 0) {
        const lastTask = newTasks[0];
        const assigner = employees.find(e => e.id === lastTask.assignedBy)?.name || "Manager";
        
        setNotification({
          title: lastTask.parentTaskId ? "New Sub-Task" : "New Assignment",
          message: `${assigner} ${lastTask.parentTaskId ? 'delegated' : 'assigned'}: ${lastTask.description}`
        });

        if ("Notification" in window && Notification.permission === "granted") {
          new Notification("OpsPro Task Update", {
            body: `${assigner} assigned: ${lastTask.description}`,
            icon: '/favicon.ico'
          });
        }
      }
      localStorage.setItem(`last_seen_${currentUser.id}`, Date.now().toString());
    }
  }, [currentUser, appReady, tasks]);

  // --- Handlers with Robust UUIDs ---

  const addTask = async (description: string, assignedTo?: string, parentTaskId?: string, deadline?: number) => {
    if (!currentUser) return;

    const newTask: DealershipTask = {
      id: crypto.randomUUID(),
      description,
      status: 'pending',
      createdAt: Date.now(),
      deadline: deadline,
      assignedTo: assignedTo === 'none' ? undefined : assignedTo,
      assignedBy: currentUser.id,
      parentTaskId: parentTaskId
    };

    // No manual setTasks, relying on onSnapshot
    await DataService.addTask(newTask);
  };

  const completeTask = async (taskId: string, proofData: { imageUrl: string, timestamp: number }) => {
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;

    const updatedTask: DealershipTask = { 
      ...task, 
      status: 'completed' as TaskStatus, 
      completedAt: proofData.timestamp, 
      proof: proofData 
    };

    await DataService.updateTask(updatedTask);
  };

  const deleteTask = async (taskId: string) => {
    // Delete the task AND any sub-tasks attached to it
    // Identify subtasks first from local state
    const subTasks = tasks.filter(t => t.parentTaskId === taskId);

    // Delete main task
    await DataService.deleteTask(taskId);
    
    // Delete subtasks
    for (const st of subTasks) {
      await DataService.deleteTask(st.id);
    }
  };

  const addEmployee = async (name: string, mobile: string, role: UserRole = 'staff') => {
    const newEmployee = { id: crypto.randomUUID(), name, mobile, role };
    setEmployees(prev => [...prev, newEmployee]); // Optimistic update
    await DataService.addEmployee(newEmployee);
  };

  const removeEmployee = async (id: string) => {
    setEmployees(prev => prev.filter(e => e.id !== id)); // Optimistic update
    await DataService.removeEmployee(id);
  };

  const addFinanceRecord = async (record: Omit<FinanceRecord, 'id'>) => {
    const newRecord = { ...record, id: crypto.randomUUID() };
    setFinanceRecords(prev => [...prev, newRecord]); // Optimistic update
    await DataService.addFinance(newRecord);
  };

  const removeFinanceRecord = async (id: string) => {
    setFinanceRecords(prev => prev.filter(r => r.id !== id)); // Optimistic update
    await DataService.removeFinance(id);
  };

  const addReceivableRecord = async (record: Omit<ReceivableRecord, 'id'>) => {
    const newRecord = { ...record, id: crypto.randomUUID() };
    setReceivableRecords(prev => [...prev, newRecord]); // Optimistic update
    await DataService.addReceivable(newRecord);
  };

  const removeReceivableRecord = async (id: string) => {
    setReceivableRecords(prev => prev.filter(r => r.id !== id)); // Optimistic update
    await DataService.removeReceivable(id);
  };

  const addDocument = async (doc: Omit<DocumentRecord, 'id'>) => {
    const newDoc = { ...doc, id: crypto.randomUUID() };
    setDocuments(prev => [newDoc, ...prev]); // Optimistic update
    await DataService.addDocument(newDoc);
  };

  const removeDocument = async (id: string) => {
    setDocuments(prev => prev.filter(d => d.id !== id)); // Optimistic update
    await DataService.removeDocument(id);
  };

  const handleLogin = (user: Employee) => {
    setCurrentUser(user);
    localStorage.setItem('dealership_current_user', JSON.stringify(user));
    setActiveTab(AppTab.TASKS);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('dealership_current_user');
    // Clear sensitive data immediately from memory
    setFinanceRecords([]);
    setReceivableRecords([]);
    setDocuments([]);
  };

  if (loadError) {
    return (
      <div className="h-screen bg-[#0F172A] flex flex-col items-center justify-center text-white p-8 text-center">
        <AlertTriangle className="w-16 h-16 text-red-500 mb-4" />
        <h2 className="text-xl font-bold mb-2">System Error</h2>
        <p className="text-slate-400 text-sm mb-6">{loadError}</p>
        <button onClick={() => window.location.reload()} className="bg-blue-600 text-white px-8 py-3 rounded-xl font-bold">Retry Boot</button>
      </div>
    );
  }

  if (!appReady) {
    return (
      <div className="h-screen bg-[#0F172A] flex flex-col items-center justify-center text-white p-8">
        <Loader2 className="w-12 h-12 text-blue-500 animate-spin mb-4" />
        <p className="text-xs font-black uppercase tracking-[0.3em] text-slate-500">Initializing OpsPro Secure</p>
      </div>
    );
  }

  if (!currentUser) {
    return <LoginScreen employees={employees} onLogin={handleLogin} />;
  }

  const isManager = currentUser.role === 'manager';

  return (
    <div className="flex flex-col h-screen max-w-md mx-auto bg-slate-50 relative overflow-hidden font-sans">
      {/* Global Notification Banner */}
      {notification && (
        <div className="fixed top-2 left-2 right-2 max-w-md mx-auto z-[100] animate-in slide-in-from-top-4 duration-500">
          <div className="bg-[#0F172A] text-white p-4 rounded-2xl shadow-2xl border border-blue-500/30 flex items-center gap-4">
            <div className="bg-blue-600 p-2 rounded-xl">
              <Bell className="w-5 h-5 animate-bounce" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-[10px] font-black uppercase tracking-widest text-blue-400">{notification.title}</p>
              <p className="text-sm font-bold truncate">{notification.message}</p>
            </div>
            <button onClick={() => setNotification(null)} className="p-1 hover:bg-white/10 rounded-lg">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Executive Header */}
      <header className="bg-[#0F172A] text-white p-5 sticky top-0 z-30 flex items-center justify-between shadow-2xl border-b border-white/5">
        <div className="flex items-center gap-2">
          <div className="bg-blue-600 p-1.5 rounded-lg shadow-lg shadow-blue-500/20">
            <Car className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-lg font-black tracking-tighter italic leading-none">OpsPro</h1>
            <div className="flex items-center gap-1.5 mt-1">
              <div className={`w-1.5 h-1.5 rounded-full ${isSyncing ? 'bg-amber-500 animate-pulse' : 'bg-emerald-500'}`} />
              <span className="text-[7px] font-black uppercase tracking-widest text-slate-400">
                {isSyncing ? 'Syncing...' : 'Live Connected'}
              </span>
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="text-right">
            <p className="text-[10px] font-black leading-none">{currentUser.name}</p>
            <p className="text-[8px] text-blue-400 uppercase font-black tracking-widest mt-0.5">{currentUser.role}</p>
          </div>
          <button 
            onClick={handleLogout}
            className="p-2.5 bg-slate-800/50 hover:bg-slate-800 rounded-xl text-slate-400 hover:text-white transition-all border border-white/5"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto pb-24 px-4 pt-4">
        {activeTab === AppTab.TASKS && (
          <Dashboard 
            tasks={tasks} 
            employees={employees} 
            currentUser={currentUser} 
            onAddTask={addTask} 
            onCompleteTask={completeTask}
            onDeleteTask={deleteTask}
          />
        )}
        
        {isManager && (
          <>
            {activeTab === AppTab.TEAM && (
              <TeamManager employees={employees} onAddEmployee={addEmployee} onRemoveEmployee={removeEmployee} />
            )}
            {activeTab === AppTab.FINANCE && (
              <FinanceManager records={financeRecords} onAddRecord={addFinanceRecord} onRemoveRecord={removeFinanceRecord} />
            )}
            {activeTab === AppTab.RECEIVABLES && (
              <ReceivablesManager records={receivableRecords} onAddRecord={addReceivableRecord} onRemoveRecord={removeReceivableRecord} />
            )}
            {activeTab === AppTab.DOCUMENTS && (
              <DocumentManager documents={documents} onAddDocument={addDocument} onRemoveDocument={removeDocument} />
            )}
          </>
        )}
      </main>

      {/* Modern Bottom Navigation */}
      <nav className="bg-white border-t border-slate-200 fixed bottom-0 left-0 right-0 max-w-md mx-auto z-40 safe-bottom shadow-[0_-10px_40px_rgba(15,23,42,0.1)] rounded-t-[2.5rem]">
        <div className={`flex justify-around items-center h-20 px-2 ${isManager ? 'overflow-x-auto no-scrollbar' : ''}`}>
          <NavBtn active={activeTab === AppTab.TASKS} onClick={() => setActiveTab(AppTab.TASKS)} icon={<ClipboardList className="w-6 h-6" />} label="Task" />
          
          {isManager && (
            <>
              <NavBtn active={activeTab === AppTab.FINANCE} onClick={() => setActiveTab(AppTab.FINANCE)} icon={<Wallet className="w-6 h-6" />} label="Payables" />
              <NavBtn active={activeTab === AppTab.RECEIVABLES} onClick={() => setActiveTab(AppTab.RECEIVABLES)} icon={<ArrowDownCircle className="w-6 h-6" />} label="Receivables" />
              <NavBtn active={activeTab === AppTab.DOCUMENTS} onClick={() => setActiveTab(AppTab.DOCUMENTS)} icon={<FileText className="w-6 h-6" />} label="Vault" />
              <NavBtn active={activeTab === AppTab.TEAM} onClick={() => setActiveTab(AppTab.TEAM)} icon={<Users className="w-6 h-6" />} label="Team" />
            </>
          )}
        </div>
      </nav>
    </div>
  );
};

const NavBtn = ({ active, onClick, icon, label }: { active: boolean, onClick: () => void, icon: any, label: string }) => (
  <button onClick={onClick} className={`flex-1 flex flex-col items-center gap-1.5 transition-all min-w-[70px] ${active ? 'text-blue-600' : 'text-slate-400'}`}>
    <div className={`p-2.5 rounded-[1.2rem] transition-all duration-500 ${active ? 'bg-blue-50 scale-110 shadow-inner ring-4 ring-blue-500/5' : ''}`}>{icon}</div>
    <span className={`text-[8px] font-black uppercase tracking-[0.15em] ${active ? 'opacity-100' : 'opacity-40'}`}>{label}</span>
  </button>
);

export default App;