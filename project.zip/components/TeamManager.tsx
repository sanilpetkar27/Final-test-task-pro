
import React, { useState } from 'react';
import { Employee, UserRole } from '../types';
import { UserPlus, UserMinus, User, ShieldCheck, Phone } from 'lucide-react';

interface TeamManagerProps {
  employees: Employee[];
  onAddEmployee: (name: string, mobile: string, role: UserRole) => void;
  onRemoveEmployee: (id: string) => void;
}

const TeamManager: React.FC<TeamManagerProps> = ({ employees, onAddEmployee, onRemoveEmployee }) => {
  const [newName, setNewName] = useState('');
  const [newMobile, setNewMobile] = useState('');
  const [newRole, setNewRole] = useState<UserRole>('staff');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newMobile.trim()) return;
    
    // Basic mobile validation
    if (newMobile.length < 10) {
      alert("Please enter a valid 10-digit mobile number");
      return;
    }

    onAddEmployee(newName.trim(), newMobile.trim(), newRole);
    setNewName('');
    setNewMobile('');
    setNewRole('staff');
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-br from-slate-800 to-slate-900 p-6 rounded-3xl text-white shadow-xl">
        <div className="flex items-center gap-2 mb-2">
          <ShieldCheck className="w-5 h-5 text-blue-400" />
          <h2 className="text-xl font-bold italic">Team</h2>
        </div>
        <p className="text-slate-400 text-sm">
          Manage staff members and assign their access permissions.
        </p>
      </div>

      <section className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200">
        <h3 className="text-xs font-bold text-slate-500 mb-3 uppercase tracking-wider">Add Staff Member</h3>
        <form onSubmit={handleSubmit} className="space-y-3">
          <input 
            type="text" 
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            placeholder="Full Name..."
            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
            required
          />
          <div className="relative">
            <input 
              type="tel" 
              value={newMobile}
              onChange={(e) => {
                const val = e.target.value.replace(/\D/g, '').slice(0, 10);
                setNewMobile(val);
              }}
              placeholder="Mobile Number (Login ID)"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-10 pr-4 py-3 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
              required
            />
            <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          </div>
          <div className="flex gap-2">
            <select 
              value={newRole}
              onChange={(e) => setNewRole(e.target.value as UserRole)}
              className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm text-slate-900 outline-none"
            >
              <option value="staff" className="text-slate-900">Staff (Tasks Only)</option>
              <option value="manager" className="text-slate-900">Manager (Full Access)</option>
            </select>
            <button 
              type="submit"
              className="bg-blue-600 text-white p-3 px-6 rounded-xl active:scale-95 transition-transform flex items-center gap-2 font-bold text-sm"
            >
              <UserPlus className="w-5 h-5" />
              Add
            </button>
          </div>
        </form>
      </section>

      <div className="space-y-2">
        <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider px-1">Registered Team ({employees.length})</h3>
        {employees.length > 0 ? (
          employees.map((emp) => (
            <div 
              key={emp.id} 
              className="bg-white p-4 rounded-2xl border border-slate-200 flex items-center justify-between group transition-all active:bg-slate-50"
            >
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${emp.role === 'manager' ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-500'}`}>
                  {emp.name.charAt(0).toUpperCase()}
                </div>
                <div>
                  <p className="font-semibold text-slate-700">{emp.name}</p>
                  <div className="flex items-center gap-2">
                    <span className={`text-[9px] font-black uppercase px-1.5 py-0.5 rounded ${emp.role === 'manager' ? 'bg-amber-500 text-white' : 'bg-slate-200 text-slate-600'}`}>
                      {emp.role}
                    </span>
                    <span className="text-[10px] text-slate-400 font-medium">{emp.mobile}</span>
                  </div>
                </div>
              </div>
              <button 
                onClick={() => onRemoveEmployee(emp.id)}
                className="p-2 text-slate-300 hover:text-red-500 active:scale-90 transition-all"
              >
                <UserMinus className="w-5 h-5" />
              </button>
            </div>
          ))
        ) : (
          <div className="text-center py-12 bg-slate-100/50 rounded-3xl border border-dashed border-slate-200">
            <User className="w-10 h-10 mx-auto mb-2 text-slate-300" />
            <p className="text-sm text-slate-500">No staff members registered yet.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default TeamManager;
