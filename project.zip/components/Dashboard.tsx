
import React, { useState } from 'react';
import { DealershipTask, Employee } from '../types';
import TaskItem from './TaskItem';
import CompletionModal from './CompletionModal';
import DelegationModal from './DelegationModal';
import { Plus, Clock, CheckCircle2, UserPlus, ClipboardList as ClipboardIcon, CalendarClock } from 'lucide-react';

interface DashboardProps {
  tasks: DealershipTask[];
  employees: Employee[];
  currentUser: Employee;
  onAddTask: (desc: string, assignedTo?: string, parentTaskId?: string, deadline?: number) => void;
  onCompleteTask: (id: string, proof: { imageUrl: string, timestamp: number }) => void;
  onDeleteTask: (id: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ tasks, employees, currentUser, onAddTask, onCompleteTask, onDeleteTask }) => {
  const [view, setView] = useState<'pending' | 'completed'>('pending');
  const [newTaskDesc, setNewTaskDesc] = useState('');
  const [assigneeId, setAssigneeId] = useState('none');
  const [deadline, setDeadline] = useState('');
  
  const [completingTaskId, setCompletingTaskId] = useState<string | null>(null);
  const [delegatingTaskId, setDelegatingTaskId] = useState<string | null>(null);

  const isManager = currentUser.role === 'manager';

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskDesc.trim()) return;
    
    const deadlineTimestamp = deadline ? new Date(deadline).getTime() : undefined;
    
    onAddTask(newTaskDesc.trim(), assigneeId, undefined, deadlineTimestamp);
    
    setNewTaskDesc('');
    setAssigneeId('none');
    setDeadline('');
  };

  const handleDelegate = (parentTaskId: string, desc: string, targetAssigneeId: string, deadlineTimestamp?: number) => {
    onAddTask(desc, targetAssigneeId, parentTaskId, deadlineTimestamp);
    setDelegatingTaskId(null);
  };

  const filteredTasks = tasks.filter(task => {
    // If I am a staff member, I should see anything assigned to me, root or sub-task.
    if (!isManager) {
      return task.assignedTo === currentUser.id;
    }
    
    // If I am a manager, show root tasks I created or am assigned to.
    if (!task.parentTaskId) {
      return true;
    }

    return false;
  });

  const pendingTasks = filteredTasks.filter(t => t.status === 'pending');
  const completedTasks = filteredTasks.filter(t => t.status === 'completed');

  return (
    <div className="space-y-6">
      {isManager && (
        <section className="bg-white p-4 rounded-2xl shadow-sm border border-slate-200 animate-in fade-in slide-in-from-top-4">
          <h2 className="text-xs font-black text-slate-500 mb-3 uppercase tracking-widest flex items-center gap-2">
            <Plus className="w-3 h-3" />
            Assign New Operation
          </h2>
          <form onSubmit={handleAddTask} className="space-y-3">
            <input 
              type="text" 
              value={newTaskDesc}
              onChange={(e) => setNewTaskDesc(e.target.value)}
              placeholder="What needs to be done?"
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all placeholder:text-slate-400"
            />
            
            <div className="flex gap-2">
              <div className="flex-1 relative">
                <select 
                  value={assigneeId}
                  onChange={(e) => setAssigneeId(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 appearance-none transition-all pr-10"
                >
                  <option value="none" className="text-slate-900">Anyone / Unassigned</option>
                  {employees.map(emp => (
                    <option key={emp.id} value={emp.id} className="text-slate-900">
                      {emp.name} ({emp.role === 'manager' ? 'Manager' : 'Staff'})
                    </option>
                  ))}
                </select>
                <UserPlus className="w-4 h-4 text-slate-400 absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>
              
              <div className="relative w-1/3">
                <input 
                  type="datetime-local" 
                  value={deadline}
                  onChange={(e) => setDeadline(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-3 text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                />
              </div>
            </div>

            <button 
              type="submit"
              className="w-full bg-blue-600 text-white py-3 rounded-xl active:scale-95 transition-transform flex items-center justify-center gap-2 shadow-lg shadow-blue-100 font-bold"
            >
              <Plus className="w-5 h-5" />
              Create Task
            </button>
          </form>
        </section>
      )}

      {!isManager && (
        <div className="bg-blue-600 p-6 rounded-3xl text-white shadow-xl shadow-blue-200 mb-4 overflow-hidden relative">
          <div className="relative z-10">
            <p className="text-blue-100 text-[10px] font-black uppercase tracking-widest mb-1">Welcome back,</p>
            <h2 className="text-2xl font-black italic">{currentUser.name}</h2>
            <p className="text-blue-100 text-xs mt-2 font-medium opacity-80">You have {pendingTasks.length} tasks to attend to.</p>
          </div>
          <ClipboardIcon className="absolute -right-4 -bottom-4 w-32 h-32 text-white/10 rotate-12" />
        </div>
      )}

      <div className="flex bg-slate-200/50 p-1.5 rounded-2xl border border-slate-200">
        <button 
          onClick={() => setView('pending')}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-xs font-black uppercase tracking-widest rounded-xl transition-all ${view === 'pending' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500'}`}
        >
          <Clock className="w-4 h-4" />
          Pending ({pendingTasks.length})
        </button>
        <button 
          onClick={() => setView('completed')}
          className={`flex-1 flex items-center justify-center gap-2 py-2.5 text-xs font-black uppercase tracking-widest rounded-xl transition-all ${view === 'completed' ? 'bg-white text-green-600 shadow-sm' : 'text-slate-500'}`}
        >
          <CheckCircle2 className="w-4 h-4" />
          Done ({completedTasks.length})
        </button>
      </div>

      <div className="space-y-3 pb-8">
        {(view === 'pending' ? pendingTasks : completedTasks).map(task => (
          <TaskItem 
            key={task.id} 
            task={task} 
            subTasks={tasks.filter(t => t.parentTaskId === task.id)}
            parentTask={tasks.find(t => t.id === task.parentTaskId)}
            employees={employees}
            currentUser={currentUser}
            assigneeName={employees.find(e => e.id === task.assignedTo)?.name}
            assignerName={employees.find(e => e.id === task.assignedBy)?.name}
            onMarkComplete={() => setCompletingTaskId(task.id)} 
            onDelegate={() => setDelegatingTaskId(task.id)}
            onSubTaskComplete={(subTaskId) => setCompletingTaskId(subTaskId)} 
            onDelete={() => onDeleteTask(task.id)}
          />
        ))}
        {(view === 'pending' ? pendingTasks : completedTasks).length === 0 && (
          <div className="text-center py-20 bg-white rounded-3xl border border-dashed border-slate-200">
            {view === 'pending' ? <CheckCircle2 className="w-12 h-12 mx-auto mb-3 text-slate-200" /> : <Clock className="w-12 h-12 mx-auto mb-3 text-slate-200" />}
            <p className="text-slate-400 font-bold">{view === 'pending' ? 'All clear!' : 'No completions yet.'}</p>
          </div>
        )}
      </div>

      {completingTaskId && (
        <CompletionModal 
          onClose={() => setCompletingTaskId(null)}
          onConfirm={(photo) => {
            onCompleteTask(completingTaskId, { imageUrl: photo, timestamp: Date.now() });
            setCompletingTaskId(null);
          }}
        />
      )}

      {delegatingTaskId && (
        <DelegationModal 
          employees={employees}
          onClose={() => setDelegatingTaskId(null)}
          onConfirm={(desc, targetId, deadline) => handleDelegate(delegatingTaskId, desc, targetId, deadline)}
        />
      )}
    </div>
  );
};

export default Dashboard;
